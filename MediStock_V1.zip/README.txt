MediStock V1
============
Mobile-friendly medical store stock management starter.

Included:
- Dashboard
- Medicine Master
- Supplier Master
- GRN / Purchase entry
- Batch-wise stock
- Stock ledger
- Sales
- Expiry management
- Reports
- JSON backup

Data is stored in the browser's localStorage in this V1. Before using it for real business records, add a server/cloud database, authentication, audit controls, and proper backup/restore testing.
